Bu ZIP, game.ejs icindeki titan cizim hatasini duzeltir ve yeni ayri PNG titan dosyalarini ekler.
Proje kok dizinine cikar: backend/views/game.ejs ve backend/public/images/titans/ klasoru yerlesmelidir.
Tarayicida Ctrl+F5 yap.
